ReadMe 

This example is to illustrate how iterative closest point registration improve alignment. 
Step 1.
ShapeWorksGroom mickey.group1.preprocess2.params antialias fastmarching blur icp
Note that "icp" should be the last argument in the command line.

Step 2.
ShapeWorksRun mickey.group1.correspondence.params

Step 3.
ShapeWorksView mickey.group1.analyze.params