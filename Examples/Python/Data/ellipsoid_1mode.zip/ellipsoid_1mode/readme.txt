Unaligned ellipsoids that vary in center, rotation, segmentation size, and x radius. Do not have uniform spacing.
Generated using the following Python code:
	import shapeworks
	import ShapeCohortGen

	out_dir = "/ellipsoid_1mode/"
	ss_generator = ShapeCohortGen.EllipsoidCohortGenerator(out_dir)
	num_samples = 15
	meshFiles = ss_generator.generate(num_samples, randomize_center=True, randomize_rotation=True, randomize_x_radius=True, randomize_y_radius=False, randomize_z_radius=False)
	segFiles = ss_generator.generate_segmentations(randomize_size=True, spacing=[1,1,2], allow_on_boundary=True)
	imageFiles = ss_generator.generate_images()